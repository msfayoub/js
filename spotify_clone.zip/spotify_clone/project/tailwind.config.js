module.exports = {
  content: [
    "./src/**/*.{vue,js,ts,jsx,tsx}", // Vue file support
    "./public/index.html",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};
